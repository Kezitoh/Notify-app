export const environment = {
  production: true,
  // url: 'https://notify.admyst.com'
  // url: 'http://192.168.3.104:8000'
  // url: 'http://localhost:8000'
  url: 'http://192.168.1.116:8000'
};
